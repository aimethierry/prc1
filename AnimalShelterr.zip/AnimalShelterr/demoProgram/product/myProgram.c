/* 
 * auteur : Ella van der Sanden
 * myProgram
 */

#include <stdio.h>


#include "mySecondFile.h"
#include "otherFile.h"

int main (void)
{
	printf(" hi there \n" );
	printf ("call some function : %d \n" , someFunction(3,7));
	otherFunction(6,4);
	
	return 0;
}
	

  






