/* 
 * auteur : Ella van der Sanden
 * mySecondFile
 */

#ifndef MYSECONDFILE
#define MYSECONDFILE

#include <stdio.h>


int someFunction (int a,int b);


#endif
	



