/* 
 * auteur : Ella van der Sanden
 * mySecondFile
 */

#ifndef OTHERFILE
#define OTHERFILE

#include <stdio.h>


int otherFunction (int a,int b);

#endif
	



