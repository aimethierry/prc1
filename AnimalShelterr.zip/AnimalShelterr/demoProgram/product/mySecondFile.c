/* 
 * auteur : Ella van der Sanden
 * mySecondFile
 */

#include <stdio.h>


int someFunction (int a,int b)
{
	printf(" someFunction\n" );
	return a+b;
}
	



