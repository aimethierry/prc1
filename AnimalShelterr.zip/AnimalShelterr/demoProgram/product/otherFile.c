/* 
 * auteur : Ella van der Sanden
 * mySecondFile
 */
 

#include <stdio.h>

#include "otherFile.h"


int otherFunction (int a,int b)
{
	printf(" other Function\n" );
	return a*b;
}
	



